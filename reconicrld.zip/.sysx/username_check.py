
import requests

def run(username):
    print(f"[•] Cek username '{username}' di beberapa platform:")
    platforms = {
        "Twitter": f"https://twitter.com/{username}",
        "GitHub": f"https://github.com/{username}",
        "Instagram": f"https://instagram.com/{username}"
    }
    headers = {'User-Agent': 'Mozilla/5.0'}
    for name, url in platforms.items():
        try:
            r = requests.head(url, headers=headers, timeout=5)
            if r.status_code == 200:
                print(f"[FOUND] {name}: {url}")
            else:
                print(f"[NOT FOUND] {name}")
        except:
            print(f"[ERROR] {name}")
