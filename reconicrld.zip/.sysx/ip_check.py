
import requests

def run(ip):
    print(f"[•] Cek IP: {ip}")
    try:
        r = requests.get(f"http://ip-api.com/json/{ip}")
        data = r.json()
        for k, v in data.items():
            print(f"{k.capitalize()}: {v}")
    except:
        print("[!] Gagal mengambil info IP.")
