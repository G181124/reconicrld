
import requests

def run(url):
    print(f"[•] Cek URL: {url}")
    try:
        r = requests.get(url, timeout=5)
        print(f"[✓] Status: {r.status_code}")
    except:
        print("[!] URL tidak dapat diakses.")
