
import socket

def run(domain):
    print(f"[•] Cek domain: {domain}")
    try:
        ip = socket.gethostbyname(domain)
        print(f"[✓] IP Address: {ip}")
    except Exception as e:
        print(f"[!] Error: {e}")
