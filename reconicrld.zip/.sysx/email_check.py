
import re

def run(email):
    print(f"[•] Validasi email: {email}")
    if re.match(r"[^@]+@[^@]+\.[^@]+", email):
        print("[✓] Format valid.")
    else:
        print("[!] Format tidak valid.")
