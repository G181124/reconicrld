
import re

def run(hash_str):
    print(f"[•] Cek hash: {hash_str}")
    if re.match(r"^[a-f0-9]{32}$", hash_str):
        print("[✓] Tipe kemungkinan: MD5 / NTLM")
    elif re.match(r"^[a-f0-9]{40}$", hash_str):
        print("[✓] Tipe kemungkinan: SHA-1")
    elif re.match(r"^[a-f0-9]{64}$", hash_str):
        print("[✓] Tipe kemungkinan: SHA-256")
    else:
        print("[?] Tipe tidak dikenali")
