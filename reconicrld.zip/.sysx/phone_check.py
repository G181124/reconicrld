
import re

def run(phone):
    phone = re.sub(r'\D', '', phone)
    if phone.startswith('62'):
        phone = '0' + phone[2:]
    print(f"[•] Nomor diformat ulang: {phone}")
    print("[✓] (Contoh) Nomor ini kemungkinan Telkomsel atau XL.")
