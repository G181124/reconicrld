
import socket

def run(target):
    ports = [21, 22, 80, 443, 8080]
    print(f"[•] Scan port {target}")
    for port in ports:
        s = socket.socket()
        s.settimeout(1)
        try:
            s.connect((target, port))
            print(f"[OPEN] Port {port}")
        except:
            pass
        s.close()
