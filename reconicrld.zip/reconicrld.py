
#!/usr/bin/env python3
import argparse
import sys
import os
from .sysx.username_check import run as run_username
from .sysx.phone_check import run as run_phone
from .sysx.domain_check import run as run_domain
from .sysx.ip_check import run as run_ip
from .sysx.hash_identifier import run as run_hash
from .sysx.port_scanner import run as run_scan
from .sysx.email_check import run as run_email
from .sysx.url_check import run as run_url

BANNER = """
#    _ \                            _)         _ \   |      __ \  
#   |   |   _ \   __|   _ \   __ \   |   __|  |   |  |      |   | 
#   __ <    __/  (     (   |  |   |  |  (     __ <   |      |   | 
#  _| \_\ \___| \___| \___/  _|  _| _| \___| _| \_\ _____| ____/  
"""

def main():
    parser = argparse.ArgumentParser(description="ReconicRLD - Real-time OSINT Toolkit")
    parser.add_argument("--username", help="Cek username di berbagai platform")
    parser.add_argument("--phone", help="Validasi nomor HP")
    parser.add_argument("--domain", help="Info WHOIS & DNS domain")
    parser.add_argument("--ip", help="Info detail alamat IP")
    parser.add_argument("--hash-id", help="Identifikasi jenis hash")
    parser.add_argument("--scan", help="Scan port dan banner grab")
    parser.add_argument("--email", help="Validasi email dan MX record")
    parser.add_argument("--url", help="Validasi URL")

    args = parser.parse_args()
    print(BANNER)

    if args.username:
        run_username(args.username)
    elif args.phone:
        run_phone(args.phone)
    elif args.domain:
        run_domain(args.domain)
    elif args.ip:
        run_ip(args.ip)
    elif args.hash_id:
        run_hash(args.hash_id)
    elif args.scan:
        run_scan(args.scan)
    elif args.email:
        run_email(args.email)
    elif args.url:
        run_url(args.url)
    else:
        print("[!] Gunakan --help untuk melihat opsi yang tersedia.")
        sys.exit(1)

if __name__ == "__main__":
    main()
