#!/bin/bash

echo "[*] Memasang dependensi manual..."
pip install requests dnspython beautifulsoup4

echo "[*] Menambahkan alias ke .zshrc..."
echo 'alias reconicrld="python3 $(pwd)/reconicrld.py"' >> ~/.zshrc

chmod +x reconicrld.py

echo "[*] Instalasi selesai! Jalankan 'source ~/.zshrc' untuk mulai menggunakan ReconicRLD."
